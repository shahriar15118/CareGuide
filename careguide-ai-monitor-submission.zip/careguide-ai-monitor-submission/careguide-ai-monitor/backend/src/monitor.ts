import OpenAI from "openai";
import { ApiObservation } from "./types";

const threshold = Number(process.env.SLOW_RESPONSE_THRESHOLD_MS || 3000);
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

export type Finding = { severity: "critical" | "warning"; anomaly_type: string; message: string; details: Record<string, unknown> };

export function detectAnomalies(input: ApiObservation): Finding[] {
  const findings: Finding[] = [];
  if (input.status_code >= 500) findings.push({severity:"critical", anomaly_type:"server_error", message:`${input.api_name} returned HTTP ${input.status_code}.`, details:{status_code:input.status_code}});
  else if (input.status_code >= 400) findings.push({severity:"warning", anomaly_type:"client_error", message:`${input.api_name} returned HTTP ${input.status_code}.`, details:{status_code:input.status_code}});
  if (input.response_time_ms > threshold) findings.push({severity:input.response_time_ms > threshold * 2 ? "critical":"warning", anomaly_type:"slow_response", message:`${input.api_name} response time is ${input.response_time_ms} ms, above the ${threshold} ms threshold.`, details:{response_time_ms:input.response_time_ms, threshold_ms:threshold}});
  if (input.records_returned === 0) findings.push({severity:"warning", anomaly_type:"zero_records", message:`${input.api_name} returned zero records.`, details:{records_returned:0}});
  return findings;
}

export async function explainAnomaly(input: ApiObservation, finding: Finding): Promise<string> {
  if (!client) return `${finding.message} Recommended action: verify the upstream API health, logs, and expected data volume.`;
  try {
    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      temperature: 0.2,
      messages: [
        {role:"system", content:"You are an operations monitoring assistant. Explain API anomalies in concise, actionable language. Only use the supplied facts; do not claim a cause is confirmed. Do not include personal or patient data. Return 1-3 sentences with a suggested next step."},
        {role:"user", content:JSON.stringify({observation:input, detected_finding:finding})}
      ]
    });
    return response.choices[0]?.message?.content?.trim() || finding.message;
  } catch (error) {
    console.error("LLM explanation failed; using deterministic fallback:", error instanceof Error ? error.message : error);
    return `${finding.message} Recommended action: verify the upstream API health, logs, and expected data volume.`;
  }
}
