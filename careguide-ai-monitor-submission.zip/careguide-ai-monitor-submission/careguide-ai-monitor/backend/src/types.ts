export type ApiObservation = {
  api_name: string;
  response_time_ms: number;
  status_code: number;
  records_returned: number;
  observed_at?: string;
};
export type Anomaly = {
  id: number;
  api_name: string;
  severity: "critical" | "warning" | "info";
  anomaly_type: string;
  message: string;
  details: Record<string, unknown>;
  status_code: number;
  response_time_ms: number;
  records_returned: number;
  active: boolean;
  created_at: string;
};
