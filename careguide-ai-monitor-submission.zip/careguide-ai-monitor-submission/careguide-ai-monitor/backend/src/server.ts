import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import dotenv from "dotenv";
import { z } from "zod";
import { initDb, pool } from "./db";
import { detectAnomalies, explainAnomaly } from "./monitor";
import { ApiObservation } from "./types";
dotenv.config();

const app = express();
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));

const observationSchema = z.object({
  api_name: z.string().trim().min(1).max(120),
  response_time_ms: z.number().int().min(0).max(600000),
  status_code: z.number().int().min(100).max(599),
  records_returned: z.number().int().min(0).max(100000000),
  observed_at: z.string().datetime().optional()
});
const batchSchema = z.union([observationSchema, z.array(observationSchema).min(1).max(500)]);

app.get("/health", (_req, res) => res.json({status:"ok", service:"careguide-api-monitor"}));

app.post("/monitor", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const parsed = batchSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({error:"Invalid monitoring payload", details:parsed.error.flatten()});
    const observations: ApiObservation[] = Array.isArray(parsed.data) ? parsed.data : [parsed.data];
    const results = [];
    for (const observation of observations) {
      const findings = detectAnomalies(observation);
      const stored = [];
      for (const finding of findings) {
        const message = await explainAnomaly(observation, finding);
        const details = {...finding.details, observed_at: observation.observed_at || null};
        const result = await pool.query(
          `INSERT INTO anomalies (api_name,severity,anomaly_type,message,details,status_code,response_time_ms,records_returned)
           VALUES ($1,$2,$3,$4,$5::jsonb,$6,$7,$8) RETURNING *`,
          [observation.api_name, finding.severity, finding.anomaly_type, message, JSON.stringify(details), observation.status_code, observation.response_time_ms, observation.records_returned]
        );
        stored.push(result.rows[0]);
      }
      results.push({api_name:observation.api_name, anomalies_detected:stored.length, alerts:stored});
    }
    console.info(JSON.stringify({event:"monitor_batch_processed", observations:observations.length, anomalies:results.reduce((n,r)=>n+r.anomalies_detected,0)}));
    return res.status(201).json({processed:observations.length, total_anomalies:results.reduce((n,r)=>n+r.anomalies_detected,0), results});
  } catch (error) { next(error); }
});

app.get("/alerts", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const active = req.query.active === undefined ? true : req.query.active === "true";
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
    const result = await pool.query(`SELECT * FROM anomalies WHERE active=$1 ORDER BY created_at DESC LIMIT $2`, [active, limit]);
    res.json({count:result.rowCount, alerts:result.rows});
  } catch (error) { next(error); }
});

app.patch("/alerts/:id/resolve", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({error:"Invalid alert id"});
    const result = await pool.query(`UPDATE anomalies SET active=FALSE WHERE id=$1 RETURNING *`, [id]);
    if (!result.rowCount) return res.status(404).json({error:"Alert not found"});
    res.json({alert:result.rows[0]});
  } catch (error) { next(error); }
});

app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  console.error("Unhandled request error:", err instanceof Error ? err.message : err);
  res.status(500).json({error:"Internal server error"});
});

const port = Number(process.env.PORT || 4000);
initDb().then(() => app.listen(port, () => console.info(`API Monitor backend listening on port ${port}`)))
  .catch((error) => { console.error("Database initialization failed:", error); process.exit(1); });
