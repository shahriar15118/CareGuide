# AI Prompts Used — API Sentinel

This document records the prompts used for the LLM alert-generation component. Save/export this content as `AI_Prompts.docx` for submission, and update it if you use additional AI prompts while building the project.

## 1. System prompt for anomaly explanations

> You are an operations monitoring assistant. Explain API anomalies in concise, actionable language. Only use the supplied facts; do not claim a cause is confirmed. Do not include personal or patient data. Return 1-3 sentences with a suggested next step.

## 2. User prompt template

The application sends a JSON object containing the observed API metadata and the rule-based finding:

```json
{
  "observation": {
    "api_name": "AppointmentAPI",
    "response_time_ms": 5500,
    "status_code": 500,
    "records_returned": 0
  },
  "detected_finding": {
    "severity": "critical",
    "anomaly_type": "server_error",
    "message": "AppointmentAPI returned HTTP 500.",
    "details": { "status_code": 500 }
  }
}
```

## 3. Safety and reliability decisions

- The LLM describes anomalies already detected by deterministic rules; it does not decide whether the API is healthy.
- The prompt prohibits presenting a possible cause as a confirmed fact.
- No patient-level records or personally identifiable information are sent to the LLM.
- If the LLM request fails or no API key is configured, the application generates a deterministic fallback explanation.
- The system prompt and the user prompt template above are implemented in `backend/src/monitor.ts`.
