# API Sentinel — Intelligent API Monitoring & Alert System

An assessment-ready prototype that validates API response metadata, detects anomalies, optionally uses an LLM to explain findings, stores alerts in PostgreSQL, and presents active alerts in a React dashboard.

> **Privacy note:** The sample project uses synthetic API metadata only. Do not submit real patient records or personally identifiable information to an LLM. This is a demonstration prototype, not a certified clinical monitoring product.

## Features

- `POST /monitor`: accepts one observation or a batch of up to 500 observations.
- Detects HTTP 5xx and 4xx responses, slow response times, and zero returned records.
- Optional OpenAI-powered human-readable explanations; deterministic fallback if no key is set or the LLM call fails.
- PostgreSQL persistence for anomalies.
- `GET /alerts`: lists active alerts by default; supports `?active=false` and `?limit=100`.
- `PATCH /alerts/:id/resolve`: resolves an alert.
- React dashboard with severity, response time, HTTP status, timestamps, sample batch trigger, and resolve action.
- Zod input validation, parameterized SQL, batch limits, error handling, and basic logs.

## Requirements

- Node.js 20+ (Node 22 recommended)
- PostgreSQL 14+
- Optional OpenAI API key for LLM-generated descriptions

## 1. Create the database

Start PostgreSQL and create a database named `api_monitor` (or use your own name):

```sql
CREATE DATABASE api_monitor;
```

## 2. Configure and run the backend

```bash
cd backend
cp .env.example .env
```

Edit `backend/.env` and set `DATABASE_URL` to your local PostgreSQL connection string. `OPENAI_API_KEY` is optional. Never commit `.env` or share your key.

```bash
npm install
npm run dev
```

The server initializes the `anomalies` table on startup and listens on `http://localhost:4000`.

Check health:

```bash
curl http://localhost:4000/health
```

## 3. Run the frontend

In a second terminal:

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Open the Vite URL printed in the terminal, usually `http://localhost:5173`.

## 4. Run a sample monitoring batch

Click **Run sample check** in the dashboard, or submit the sample JSON from `backend/data/sample-responses.json`:

```bash
curl -X POST http://localhost:4000/monitor \
  -H 'Content-Type: application/json' \
  --data-binary @backend/data/sample-responses.json
```

Expected behavior: healthy observations may create no alerts; observations with HTTP errors, response times above the configured threshold, or zero records create stored alerts. The sample file intentionally includes several anomaly types.

## API contract

### `POST /monitor`

Accepts one observation or an array:

```json
{
  "api_name": "AppointmentAPI",
  "response_time_ms": 5500,
  "status_code": 500,
  "records_returned": 0
}
```

All fields are required. `observed_at` is optional and, if supplied, must be an ISO datetime. Limits: response time 0–600000 ms, status 100–599, records 0–100000000, batch 1–500 items.

### `GET /alerts`

- `GET /alerts` — active alerts
- `GET /alerts?active=false` — resolved alerts
- `GET /alerts?limit=50` — limit results (maximum 500)

### `PATCH /alerts/:id/resolve`

Marks the given alert inactive.

### `GET /health`

Returns a basic service health response. This does not verify database readiness after startup.

## Configuration

| Variable | Purpose | Default |
|---|---|---|
| `PORT` | Backend port | `4000` |
| `DATABASE_URL` | PostgreSQL connection | Required |
| `FRONTEND_ORIGIN` | Allowed frontend origin for CORS | `http://localhost:5173` |
| `OPENAI_API_KEY` | Enables LLM explanations | Optional |
| `OPENAI_MODEL` | OpenAI chat model | `gpt-4o-mini` |
| `SLOW_RESPONSE_THRESHOLD_MS` | Slow-response threshold | `3000` |
| `VITE_API_BASE_URL` | Frontend backend URL | `http://localhost:4000` |

## Detection logic

- HTTP status >= 500: critical server error.
- HTTP status >= 400: warning client error.
- Response time above threshold: warning; above twice threshold: critical.
- Zero records: warning.

A single observation can trigger multiple anomalies. Threshold-based detection is deterministic; the LLM is used only to explain an already-detected finding.

## AI prompt documentation

Prompt text and the safety/reliability approach are documented in `AI_Prompts.docx.md`. Convert or paste this content into a Word document named `AI_Prompts.docx` for the required submission. Update it with any additional prompts used during development.

## Build checks

```bash
cd backend && npm run typecheck && npm run build
cd ../frontend && npm run build
```

## Repository structure

```text
backend/
  src/db.ts          PostgreSQL initialization
  src/monitor.ts     Rule detection + optional LLM explanation
  src/server.ts      Express routes and validation
  data/              Synthetic sample input
frontend/
  src/App.tsx        Dashboard UI and API client
  src/styles.css     Responsive styling
AI_Prompts.docx.md   Prompt record to convert to DOCX
README.md
```

## Known limitations and production next steps

- Input is monitoring metadata; the app does not actively probe third-party URLs on a schedule.
- Add authentication/authorization, rate limiting, secrets management, audit logs, migrations, tests, and alert deduplication before production.
- Add email/webhook notification delivery and background jobs if needed.
- Add automated tests and deploy with HTTPS and restricted database access.
- Configure CORS and API credentials securely for any hosted deployment.

## Assessment submission checklist

- [ ] Push the full source code to GitHub.
- [ ] Confirm the README setup instructions work on a clean environment.
- [ ] Add `AI_Prompts.docx` (created from `AI_Prompts.docx.md`) if AI was used.
- [ ] Record a 5–10 minute walkthrough using `docs/VIDEO_DEMO_SCRIPT.md`.
- [ ] Email the GitHub repository link and video/Drive link by the deadline.
