
import { useCallback, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock3,
  RefreshCw,
  Server,
  ShieldCheck,
  Zap,
  CircleCheck,
  ExternalLink,
  History,
  Filter,
} from "lucide-react";

type Severity = "critical" | "warning" | "info";
type AlertFilter = "all" | "active" | "critical" | "warning" | "resolved";
type View = "overview" | "health" | "history";

type Alert = {
  id: number;
  api_name: string;
  severity: Severity;
  anomaly_type: string;
  message: string;
  details: Record<string, unknown>;
  status_code: number;
  response_time_ms: number;
  records_returned: number;
  active: boolean;
  created_at: string;
};

type Observation = {
  api_name: string;
  response_time_ms: number;
  status_code: number;
  records_returned: number;
};

const API = (
  import.meta.env.VITE_API_BASE_URL || "http://localhost:4000"
).replace(/\/$/, "");

const samples: Observation[] = [
  {
    api_name: "PatientDataAPI",
    response_time_ms: 1200,
    status_code: 200,
    records_returned: 50,
  },
  {
    api_name: "AppointmentAPI",
    response_time_ms: 5500,
    status_code: 500,
    records_returned: 0,
  },
  {
    api_name: "BillingAPI",
    response_time_ms: 4100,
    status_code: 200,
    records_returned: 27,
  },
  {
    api_name: "LabResultsAPI",
    response_time_ms: 800,
    status_code: 200,
    records_returned: 0,
  },
  {
    api_name: "InsuranceAPI",
    response_time_ms: 900,
    status_code: 401,
    records_returned: 0,
  },
];

function timeAgo(value: string): string {
  const timestamp = new Date(value).getTime();

  if (!Number.isFinite(timestamp)) return "Unknown";

  const minutes = Math.max(
    0,
    Math.floor((Date.now() - timestamp) / 60000),
  );

  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;

  const hours = Math.floor(minutes / 60);

  if (hours < 24) return `${hours}h ago`;

  return `${Math.floor(hours / 24)}d ago`;
}

function describeStatus(code: number, responseTime: number): string {
  if (code >= 500) return "Server error";
  if (code >= 400) return "Client error";
  if (responseTime > 3000) return "Slow response";
  if (code >= 200 && code < 400) return "Responding";

  return "Unknown status";
}

async function readAlerts(url: string): Promise<Alert[]> {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Backend returned HTTP ${response.status}`);
  }

  const data: unknown = await response.json();

  if (
    typeof data !== "object" ||
    data === null ||
    !("alerts" in data) ||
    !Array.isArray(data.alerts)
  ) {
    throw new Error(
      "The backend response does not contain an alerts array.",
    );
  }

  return data.alerts as Alert[];
}

export default function App() {
  const [view, setView] = useState<View>("overview");
  const [alertFilter, setAlertFilter] = useState<AlertFilter>("active");
  const [activeAlerts, setActiveAlerts] = useState<Alert[]>([]);
  const [allAlerts, setAllAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const [active, history] = await Promise.all([
        readAlerts(`${API}/alerts?active=true&limit=200`),
        readAlerts(`${API}/alerts?limit=500`),
      ]);

      setActiveAlerts(active);
      setAllAlerts(history);
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Unable to load alerts from the backend.",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  function navigateToHistory(filter: AlertFilter) {
    setAlertFilter(filter);
    setView("history");
  }

  function navigateToHealth() {
    setView("health");
  }

  async function runSample() {
    setBusy(true);
    setNotice("");
    setError("");

    try {
      const response = await fetch(`${API}/monitor`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(samples),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || `Monitoring request failed (${response.status})`,
        );
      }

      const processed = data.processed ?? samples.length;
      const anomalies = data.total_anomalies ?? "an unknown number of";

      setNotice(
        `Checked ${processed} sample APIs and detected ${anomalies} anomalies.`,
      );

      await refresh();
    } catch (e) {
      setError(
        `${e instanceof Error ? e.message : "Monitoring request failed"}. ` +
          "Check that the backend and PostgreSQL are running.",
      );
    } finally {
      setBusy(false);
    }
  }

  async function resolveAlert(id: number) {
    setError("");
    setNotice("");

    try {
      const response = await fetch(`${API}/alerts/${id}/resolve`, {
        method: "PATCH",
      });

      if (!response.ok) {
        throw new Error(
          `Could not resolve alert (HTTP ${response.status})`,
        );
      }

      setNotice(`Alert #${id} was resolved.`);
      await refresh();
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Could not resolve the alert.",
      );
    }
  }

  const critical = activeAlerts.filter(
    (alert) => alert.severity === "critical",
  ).length;

  const warnings = activeAlerts.filter(
    (alert) => alert.severity === "warning",
  ).length;

  const affectedApis = new Set(
    activeAlerts.map((alert) => alert.api_name),
  ).size;

  // The latest alert for each API, based on all recorded alerts.
  const apiHealth = useMemo(() => {
    const latestByApi = new Map<string, Alert>();

    const sorted = [...allAlerts].sort(
      (a, b) =>
        new Date(b.created_at).getTime() -
        new Date(a.created_at).getTime(),
    );

    for (const alert of sorted) {
      if (!latestByApi.has(alert.api_name)) {
        latestByApi.set(alert.api_name, alert);
      }
    }

    return Array.from(latestByApi.values());
  }, [allAlerts]);

  // Apply the selected history filter without changing backend data.
  const filteredHistory = useMemo(() => {
    switch (alertFilter) {
      case "active":
        return allAlerts.filter((alert) => alert.active);

      case "critical":
        return allAlerts.filter(
          (alert) => alert.active && alert.severity === "critical",
        );

      case "warning":
        return allAlerts.filter(
          (alert) => alert.active && alert.severity === "warning",
        );

      case "resolved":
        return allAlerts.filter((alert) => !alert.active);

      case "all":
      default:
        return allAlerts;
    }
  }, [allAlerts, alertFilter]);

  const historyFilterLabel: Record<AlertFilter, string> = {
    all: "All alerts",
    active: "Active anomalies",
    critical: "Critical alerts",
    warning: "Warnings",
    resolved: "Resolved alerts",
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">
            <Activity size={23} />
          </div>

          <div>
            <strong>API Sentinel</strong>
            <span>MONITORING CONSOLE</span>
          </div>
        </div>

        <div className="workspace">
          <span className="workspace-dot" />
          OPERATIONS WORKSPACE
        </div>

        <nav className="sidebar-nav" aria-label="Main navigation">
          <NavItem
            icon={<Activity size={18} />}
            label="Overview"
            selected={view === "overview"}
            count={activeAlerts.length}
            onClick={() => setView("overview")}
          />

          <NavItem
            icon={<Server size={18} />}
            label="API Health"
            selected={view === "health"}
            onClick={navigateToHealth}
          />

          <NavItem
            icon={<History size={18} />}
            label="Alert History"
            selected={view === "history"}
            onClick={() => navigateToHistory("all")}
          />
        </nav>

        <div className="sidebar-bottom">
          <div className="status-pulse" />

          <div>
            <strong>Monitoring service</strong>
            <span>
              {loading ? "Refreshing data…" : "Dashboard connected"}
            </span>
          </div>
        </div>

        <div className="sidebar-foot">
          CARE GUIDE · ENGINEERING DEMO
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="eyebrow">
              OPERATIONS /{" "}
              {view === "overview"
                ? "OVERVIEW"
                : view === "health"
                  ? "API HEALTH"
                  : "ALERT HISTORY"}
            </div>

            <h1>
              {view === "overview"
                ? "API Monitoring"
                : view === "health"
                  ? "API Health"
                  : "Alert History"}
            </h1>

            <p>
              {view === "overview"
                ? "Monitor integrations, detect anomalies, and act before they escalate."
                : view === "health"
                  ? "Review the latest recorded response and anomaly for each API."
                  : "Review recorded alerts and their current resolution status."}
            </p>
          </div>

          <div className="top-actions">
            <div className="live-label">
              <span />
              Live dashboard
            </div>

            <button
              type="button"
              className="btn secondary"
              onClick={() => void refresh()}
              disabled={loading}
            >
              <RefreshCw
                size={16}
                className={loading ? "spin" : ""}
              />
              Refresh
            </button>
          </div>
        </header>

        {error && (
          <div className="banner error" role="alert">
            <AlertTriangle size={18} />
            <span>{error}</span>
            <button type="button" onClick={() => setError("")}>
              Dismiss
            </button>
          </div>
        )}

        {notice && (
          <div className="banner success" role="status">
            <CheckCircle2 size={18} />
            <span>{notice}</span>
            <button type="button" onClick={() => setNotice("")}>
              Dismiss
            </button>
          </div>
        )}

        {view === "overview" && (
          <>
            <section className="metrics" aria-label="Dashboard metrics">
              <Metric
                icon={<AlertTriangle />}
                label="Active anomalies"
                value={String(activeAlerts.length)}
                hint="Requires attention"
                tone="orange"
                onClick={() => navigateToHistory("active")}
              />

              <Metric
                icon={<Zap />}
                label="Critical alerts"
                value={String(critical)}
                hint="High-priority failures"
                tone="red"
                onClick={() => navigateToHistory("critical")}
              />

              <Metric
                icon={<Clock3 />}
                label="Warnings"
                value={String(warnings)}
                hint="Performance or data issues"
                tone="blue"
                onClick={() => navigateToHistory("warning")}
              />

              <Metric
                icon={<Server />}
                label="Affected APIs"
                value={String(affectedApis)}
                hint="Unique integrations"
                tone="teal"
                onClick={navigateToHealth}
              />
            </section>

            <section className="panel health-panel">
              <div className="panel-head">
                <div>
                  <h2>Monitoring activity</h2>
                  <p>
                    Run a sample batch to verify the end-to-end workflow.
                  </p>
                </div>

                <button
                  type="button"
                  className="btn primary"
                  onClick={() => void runSample()}
                  disabled={busy}
                >
                  <Zap size={16} />
                  {busy ? "Checking APIs…" : "Run sample check"}
                </button>
              </div>

              <div className="workflow">
                <WorkflowStep
                  n="01"
                  title="Receive"
                  text="JSON batch"
                />
                <div className="connector" />

                <WorkflowStep
                  n="02"
                  title="Analyze"
                  text="Rules + validation"
                />
                <div className="connector" />

                <WorkflowStep
                  n="03"
                  title="Explain"
                  text="LLM or fallback"
                />
                <div className="connector" />

                <WorkflowStep
                  n="04"
                  title="Store"
                  text="PostgreSQL alerts"
                />
              </div>
            </section>

            <section className="panel">
              <div className="panel-head alerts-head">
                <div>
                  <h2>
                    Active alerts{" "}
                    <span className="count-pill">
                      {activeAlerts.length}
                    </span>
                  </h2>
                  <p>
                    Latest unresolved anomalies, sorted by time.
                  </p>
                </div>

                <div className="updated">
                  <span className="status-dot" />
                  {loading ? "Updating…" : "Data from backend"}
                </div>
              </div>

              <AlertTable
                alerts={activeAlerts}
                loading={loading}
                emptyMessage="No active anomalies. Run a sample check to generate demonstration alerts."
                onResolve={resolveAlert}
                showResolve
              />
            </section>
          </>
        )}

        {view === "health" && (
          <section className="panel page-panel">
            <div className="panel-head">
              <div>
                <h2>Observed API status</h2>
                <p>
                  Summarized from the latest alert record for each API.
                  This is not an independent live health probe.
                </p>
              </div>

              <span className="count-pill">
                {apiHealth.length} APIs
              </span>
            </div>

            {apiHealth.length === 0 && !loading ? (
              <EmptyState
                title="No API observations yet"
                message="Run a sample check to populate API observations."
              />
            ) : (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>API</th>
                      <th>OBSERVED STATUS</th>
                      <th>HTTP</th>
                      <th>RESPONSE TIME</th>
                      <th>RECORDS</th>
                      <th>LAST OBSERVED</th>
                    </tr>
                  </thead>

                  <tbody>
                    {apiHealth.map((alert) => (
                      <tr key={alert.api_name}>
                        <td>
                          <strong className="api-name">
                            {alert.api_name}
                          </strong>
                        </td>

                        <td>
                          <span
                            className={`severity ${
                              alert.status_code >= 500
                                ? "critical"
                                : alert.status_code >= 400 ||
                                    alert.response_time_ms > 3000 ||
                                    alert.records_returned === 0
                                  ? "warning"
                                  : "info"
                            }`}
                          >
                            <span />
                            {describeStatus(
                              alert.status_code,
                              alert.response_time_ms,
                            )}
                          </span>
                        </td>

                        <td
                          className={`http-code ${
                            alert.status_code >= 500
                              ? "bad"
                              : alert.status_code >= 400
                                ? "warn"
                                : "good"
                          }`}
                        >
                          {alert.status_code}
                        </td>

                        <td
                          className={
                            alert.response_time_ms > 3000
                              ? "slow"
                              : "fast"
                          }
                        >
                          {alert.response_time_ms.toLocaleString()} ms
                        </td>

                        <td>{alert.records_returned}</td>

                        <td className="time-cell">
                          {timeAgo(alert.created_at)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}

        {view === "history" && (
          <section className="panel page-panel">
            <div className="panel-head">
              <div>
                <h2>
                  Recorded alerts{" "}
                  <span className="count-pill">
                    {filteredHistory.length}
                  </span>
                </h2>
                <p>
                  Showing: {historyFilterLabel[alertFilter]}. Use the filters
                  to change which alert records are displayed.
                </p>
              </div>

              <span className="count-pill">
                {allAlerts.length} total
              </span>
            </div>

            <div className="history-filters" aria-label="Filter alert history">
              <span className="history-filter-label">
                <Filter size={15} />
                Filter alerts
              </span>

              <div className="history-filter-buttons">
                <FilterButton
                  label="All"
                  selected={alertFilter === "all"}
                  count={allAlerts.length}
                  onClick={() => setAlertFilter("all")}
                />

                <FilterButton
                  label="Active"
                  selected={alertFilter === "active"}
                  count={activeAlerts.length}
                  onClick={() => setAlertFilter("active")}
                />

                <FilterButton
                  label="Critical"
                  selected={alertFilter === "critical"}
                  count={critical}
                  onClick={() => setAlertFilter("critical")}
                />

                <FilterButton
                  label="Warnings"
                  selected={alertFilter === "warning"}
                  count={warnings}
                  onClick={() => setAlertFilter("warning")}
                />

                <FilterButton
                  label="Resolved"
                  selected={alertFilter === "resolved"}
                  count={allAlerts.filter((alert) => !alert.active).length}
                  onClick={() => setAlertFilter("resolved")}
                />
              </div>
            </div>

            <AlertTable
              alerts={filteredHistory}
              loading={loading}
              emptyMessage={`No alerts match the "${historyFilterLabel[alertFilter]}" filter.`}
              onResolve={resolveAlert}
              showResolve
            />
          </section>
        )}

        <footer>
          <span>
            <span className="footer-dot" />
            API Sentinel <span className="footer-sep">·</span>
            AI-powered API observability
          </span>

          <span>
            Demo uses synthetic API metadata <ExternalLink size={13} />
          </span>
        </footer>
      </main>
    </div>
  );
}

function NavItem({
  icon,
  label,
  selected,
  count,
  onClick,
}: {
  icon: ReactNode;
  label: string;
  selected: boolean;
  count?: number;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={`nav-item ${selected ? "selected" : "muted"}`}
      aria-current={selected ? "page" : undefined}
      onClick={onClick}
    >
      {icon}
      <span className="nav-label">{label}</span>

      {count !== undefined && (
        <span className="nav-count">{count}</span>
      )}
    </button>
  );
}

function Metric({
  icon,
  label,
  value,
  hint,
  tone,
  onClick,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  hint: string;
  tone: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className="metric-card"
      onClick={onClick}
      aria-label={`${label}: ${value}. ${hint}. Click to view details.`}
      title={`View ${label.toLowerCase()}`}
    >
      <div className={`metric-icon ${tone}`}>
        {icon}
      </div>

      <div className="metric-label">{label}</div>
      <div className="metric-value">{value}</div>
      <div className="metric-hint">{hint}</div>
    </button>
  );
}

function FilterButton({
  label,
  selected,
  count,
  onClick,
}: {
  label: string;
  selected: boolean;
  count: number;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={`history-filter-button ${selected ? "selected" : ""}`}
      aria-pressed={selected}
      onClick={onClick}
    >
      {label}
      <span>{count}</span>
    </button>
  );
}

function WorkflowStep({
  n,
  title,
  text,
}: {
  n: string;
  title: string;
  text: string;
}) {
  return (
    <div className="workflow-step">
      <span className="step-number">{n}</span>
      <strong>{title}</strong>
      <span>{text}</span>
    </div>
  );
}

function EmptyState({
  title,
  message,
}: {
  title: string;
  message: string;
}) {
  return (
    <div className="empty">
      <div className="empty-icon">
        <ShieldCheck size={26} />
      </div>
      <h3>{title}</h3>
      <p>{message}</p>
    </div>
  );
}

function AlertTable({
  alerts,
  loading,
  emptyMessage,
  onResolve,
  showResolve = false,
}: {
  alerts: Alert[];
  loading: boolean;
  emptyMessage: string;
  onResolve: (id: number) => void;
  showResolve?: boolean;
}) {
  if (alerts.length === 0 && !loading) {
    return (
      <EmptyState
        title="No alerts found"
        message={emptyMessage}
      />
    );
  }

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>API / ANOMALY</th>
            <th>SEVERITY</th>
            <th>AI-GENERATED EXPLANATION</th>
            <th>HTTP</th>
            <th>RESPONSE</th>
            <th>DETECTED</th>
            {showResolve && <th>STATUS / ACTION</th>}
          </tr>
        </thead>

        <tbody>
          {alerts.map((alert) => (
            <tr key={alert.id}>
              <td>
                <strong className="api-name">
                  {alert.api_name}
                </strong>
                <span className="subline">
                  {alert.anomaly_type.replace(/_/g, " ")}
                </span>
              </td>

              <td>
                <span className={`severity ${alert.severity}`}>
                  <span />
                  {alert.severity}
                </span>
              </td>

              <td className="message-cell">{alert.message}</td>

              <td
                className={`http-code ${
                  alert.status_code >= 500
                    ? "bad"
                    : alert.status_code >= 400
                      ? "warn"
                      : "good"
                }`}
              >
                {alert.status_code}
              </td>

              <td
                className={
                  alert.response_time_ms > 3000 ? "slow" : "fast"
                }
              >
                {alert.response_time_ms.toLocaleString()} ms
              </td>

              <td className="time-cell">
                {timeAgo(alert.created_at)}
              </td>

              {showResolve && (
                <td>
                  {alert.active ? (
                    <button
                      type="button"
                      className="resolve"
                      title={`Resolve alert ${alert.id}`}
                      aria-label={`Resolve alert ${alert.id}`}
                      onClick={() => onResolve(alert.id)}
                    >
                      <CircleCheck size={17} />
                    </button>
                  ) : (
                    <span className="severity info">
                      <span />
                      Resolved
                    </span>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
